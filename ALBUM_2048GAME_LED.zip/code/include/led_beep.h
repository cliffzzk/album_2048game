#ifndef __LED_BEEP_H__
#define __LED_BEEP_H__

#include <stdio.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <pthread.h>

#include "lcd.h"
#include "ts.h"

#define TEST_MAGIC 'x'                    //定义幻数

#define LED1 _IO(TEST_MAGIC,0)
#define LED2 _IO(TEST_MAGIC,1)
#define LED3 _IO(TEST_MAGIC,2)
#define LED4 _IO(TEST_MAGIC,3)
static int ledarr[4] ={LED1,LED2,LED3,LED4};
static char flowonbmp[4][30]={{"/album/led_beep/flowon1.bmp"},
					{"/album/led_beep/flowon2.bmp"},
					{"/album/led_beep/flowon3.bmp"},
					{"/album/led_beep/flowon4.bmp"}	
};
static bool led1_on_off = true;	//0亮 1 灭
static bool led2_on_off = true;
static bool led3_on_off = true;
static bool led4_on_off = true;

int ledfd;
pthread_t flowled_tid;
void led_beep();
void led_init();

#endif