#ifndef __LCD_H__
#define __LCD_H__

#define LCD_WIDTH  			800
#define LCD_HEIGHT 			480
#define FB_SIZE				(LCD_WIDTH * LCD_HEIGHT * 4)
#include <time.h>

typedef struct VideoBuffer {
    void   *start;  //映射到用户空间的地址
    size_t  length; //采集到数据的长度
} VideoBuffer1; //存放采集数据的位置

int  g_fb_fd;
int *g_pfb_memory;

int lcd_open(void);
void lcd_clear();
void lcd_close(void);

void lcd_draw_point(unsigned int x,unsigned int y, unsigned int color);
int lcd_draw_bmp(unsigned int x,unsigned int y,const char *pbmp_path);
int lcd_center_draw_bmp(const char *pbmp_path);
int lcd_draw_pic(const char *pbmp_path);

#define BUFFER_COUNT 4
VideoBuffer1 framebuf[BUFFER_COUNT]; 


#endif