#ifndef __ALBUM_H__
#define __ALBUM_H__

#include <sys/types.h>
#include "albumlist.h"
#include "ts.h"
#include "lcd.h"



void album();
//读取目录，把新的图片(链表中没有)插入链表
void pic_read_dir(char *path);
//显示上次最后打开的图片
bool show_lastpic();
//显示上一张或下一张图片
void show_prev_next(struct list_head *pos);
//判相册空否
bool is_album_empty(void);
// 删除照片
void del_pic(void);
//随机特效显示图片


#endif 