#include "pass.h"

int get_pass()
{
	int s_x,s_y,e_x,e_y;
	ts_get_xy(&s_x,&s_y,&e_x,&e_y);
	if(e_x>303 && e_x<349 && e_y>201 && e_y<247)
		return 1;
	if(e_x>375 && e_x<421 && e_y>201 && e_y<247)
		return 2;
	if(e_x>445 && e_x<490 && e_y>201 && e_y<247)
		return 3;
	if(e_x>303 && e_x<349 && e_y>281 && e_y<328)
		return 4;
	if(e_x>375 && e_x<421 && e_y>281 && e_y<328)
		return 5;
	if(e_x>445 && e_x<490 && e_y>281 && e_y<328)
		return 6;
	if(e_x>303 && e_x<349 && e_y>363 && e_y<408)
		return 7;
	if(e_x>375 && e_x<421 && e_y>363 && e_y<408)
		return 8;
	if(e_x>445 && e_x<490 && e_y>363 && e_y<408)
		return 9;
	return 0;
}

int inspect_pass(int pass[],int my_pass[])
{
	int i;
	for(i=0;i<4;i++)
		printf("%d\t",pass[i]);
	for(i=0;i<4;i++)
		printf("%d\t",my_pass[i]);
	
	for(i=0;i<4;i++)
	{
		if(pass[i] != my_pass[i])
			return 0;
	}
	return 1;
}

void show_pass(int bit, int num)
{
	char num_img[9][2] = {"1","2","3","4","5","6","7","8","9"};
	int x,y = 78;
	if(bit == 0)
		x = 270;
	if(bit == 1)
		x = 340;
	if(bit == 2)
		x = 410;
	if(bit == 3)
		x = 480;
	
	show_pass_num(x,y,num_img[num]);
	//lcd_draw_bmp(x,y,num_img[num]);
}

int boot_up()
{
	init_font();
	int mypass[4]={1,2,3,4};
	int i,pass[4];
	
	lcd_draw_bmp(0,0,"/album/index.bmp");
	while(1)
	{
		for(i=0;i<4;i++)
		{
			pass[i] = get_pass();
			if(pass[i] == 0)
			{
				i--;
				continue;
			}
			show_pass(i,pass[i]-1);
		}
		if(inspect_pass(pass,mypass))
		{
			printf("password true!\n");
			return 0;
		}
		else
		{
			printf("password error!\n");
			lcd_draw_bmp(0,0,"/album/index.bmp");
		}
	}
}