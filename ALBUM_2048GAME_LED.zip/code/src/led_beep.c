#include "led_beep.h"

void led_init()
{
	ledfd = open("/dev/Led",O_RDWR);
	if(ledfd < 0)
	printf("pls insmod driver!\n");
	ioctl(ledfd,LED1,1);
	ioctl(ledfd,LED2,1);
	ioctl(ledfd,LED3,1);
	ioctl(ledfd,LED4,1);
}


void *flowled()
{
	while(1)
	{
		int i;
		//int flowx = 99;
		for(i=0;i<4;i++){
			
			//点亮
			ioctl(ledfd,ledarr[i],0);
			//显示图片
			lcd_draw_bmp(0,0,flowonbmp[i]);
			//延时
			sleep(1);
			//usleep(500);
			//flowx += 80;
			//熄灭
			ioctl(ledfd,ledarr[i],1);
			//显示灭灯图片
			lcd_draw_bmp(0,0,"/album/led_beep/led_beep_back.bmp");
		}
	}
}

void led_beep()
{	
	lcd_draw_bmp(0,0,"/album/led_beep/led_beep_back.bmp");
	
	int beepfd = open("/dev/beep",O_RDWR);
	if(beepfd < 0)
	{
		printf("open beep error!\n");
	}
	
	while(1)
	{
		int s_x,s_y,e_x,e_y;		
		ts_get_xy(&s_x,&s_y,&e_x,&e_y);
		printf("led_beep\n");
			
		if(e_x>99 && e_x<179 && e_y>99 && e_y<209){				//LED1
		
			led1_on_off = !led1_on_off;		//取反
			
			if(led1_on_off){
				printf("LED1 off\n");				
				lcd_draw_bmp(99,0,"/album/led_beep/ledoff.bmp");
				ioctl(ledfd,LED1,1);
			}
			else{
				printf("LED1 on\n");
				lcd_draw_bmp(79,64,"/album/led_beep/ledon.bmp");
				ioctl(ledfd,LED1,0);
			}			
		}
		if(e_x>299 && e_x<379 && e_y>99 && e_y<209){			//LED2
		
			led2_on_off = !led2_on_off;		//取反
			
			if(led2_on_off){
				printf("LED2 off\n");				
				lcd_draw_bmp(299,0,"/album/led_beep/ledoff.bmp");
				ioctl(ledfd,LED2,1);
			}
			else{
				printf("LED2 on\n");
				lcd_draw_bmp(279,64,"/album/led_beep/ledon.bmp");
				ioctl(ledfd,LED2,0);
			}			
		}
		if(e_x>499 && e_x<579 && e_y>99 && e_y<209){			//LED3
		
			led3_on_off = !led3_on_off;		//取反
			
			if(led3_on_off){
				printf("LED3 off\n");				
				lcd_draw_bmp(499,0,"/album/led_beep/ledoff.bmp");
				ioctl(ledfd,LED3,1);
			}
			else{
				printf("LED3 on\n");
				lcd_draw_bmp(479,64,"/album/led_beep/ledon.bmp");
				ioctl(ledfd,LED3,0);
			}			
		}
		if(e_x>699 && e_x<779 && e_y>99 && e_y<209){			//LED4
		
			led4_on_off = !led4_on_off;		//取反
			
			if(led4_on_off){
				printf("LED4 off\n");				
				lcd_draw_bmp(699,0,"/album/led_beep/ledoff.bmp");
				ioctl(ledfd,LED4,1);
			}
			else{
				printf("LED4 on\n");
				lcd_draw_bmp(679,64,"/album/led_beep/ledon.bmp");
				ioctl(ledfd,LED4,0);
			}			
		}
		
		if(e_x>109 && e_x<399 && e_y>299 && e_y<369){	//flowing water light
			
			//先把全部灯关掉
			lcd_draw_bmp(0,0,"/album/led_beep/led_beep_back.bmp");
			printf("all led off\n");
			ioctl(ledfd,LED1,1);
			ioctl(ledfd,LED2,1);
			ioctl(ledfd,LED3,1);
			ioctl(ledfd,LED4,1);
			
			
			printf("flowing water light on\n");
			pthread_create(&flowled_tid, NULL, flowled, NULL);	
			while(1)
			{					
				int s_x,s_y,e_x,e_y;		
				ts_get_xy(&s_x,&s_y,&e_x,&e_y);
				if(e_x>109 && e_x<399 && e_y>299 && e_y<369){		//再次点击关闭流水灯
					pthread_cancel(flowled_tid);
					
					lcd_draw_bmp(0,0,"/album/led_beep/led_beep_back.bmp");
					printf("all led off\n");
					ioctl(ledfd,LED1,1);
					ioctl(ledfd,LED2,1);
					ioctl(ledfd,LED3,1);
					ioctl(ledfd,LED4,1);
					
					led1_on_off = true;	//0亮 1 灭
					led2_on_off = true;
					led3_on_off = true;
					led4_on_off = true;				
					break;
				}			
			}			
			
		}
		
		if(e_x>499 && e_x<599 && e_y>299 && e_y<399){	//beep
			printf("beep on\n");			
			lcd_draw_bmp(499,299,"/album/led_beep/beepon.bmp");			
			ioctl(beepfd,0,1); //响
			usleep(500000);//0.5秒
			
			printf("beep off\n");
			ioctl(beepfd,1,1); //不响			
			lcd_draw_bmp(499,299,"/album/led_beep/beepoff.bmp");
		}
		if(e_x>699 && e_x<799 && e_y>379 && e_y<479){	//exit
			printf("led_beep exit\n");
			break;
		}
	}
	
	close(beepfd);
	close(ledfd);
	return;
}
