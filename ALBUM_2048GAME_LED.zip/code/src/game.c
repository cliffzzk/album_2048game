#include "game.h"

void game(void)
{
	//打开字库
	init_font();
	//显示背景图片
	lcd_draw_bmp(0,0,"/album/2048/2048back.bmp");
	//生成随机数种子
	srand(time(NULL)); 
	//读取游戏数据
	read_gamelist(&head_game);
	//恢复游戏数据
	show_last_data();
	
	while(1)
	{
		int s_x,s_y,e_x,e_y;		
		ts_get_xy(&s_x,&s_y,&e_x,&e_y);
		//右滑
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (e_x - s_x)>50 && abs(e_y - s_y)<50)		
		{				
			move_right_pre();	//移动，合并数据(更新得分和历史最高分),再移动清除合并产生的空格
			rand_num();			//在剩余空位随机产生一个2,1/5几率产生一个4
			update_data();		//把移动后的数据插入链表
			print_game();		//显示一维数组的数据和得分、历史最高分，并判断游戏是否结束
		}
		//左滑
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (s_x - e_x)>50 && abs(e_y - s_y)<50)		
		{			
			move_left_pre();
			rand_num();
			update_data();
			print_game();
		}
		//上滑
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (s_y - e_y)>50 && abs(e_x - s_x)<50)	
		{			
			move_up_pre();
			rand_num();
			update_data();
			print_game();
		}
		//下滑
		if(e_x>0 && e_x<799 && e_y>0 && e_y<479 && (e_y - s_y)>50 && abs(e_x - s_x)<50)	
		{
			move_down_pre();
			rand_num();
			update_data();
			print_game();
		}
		//新游戏
		if(e_x>699 && e_x<799 && e_y>99 && e_y<199){
			printf("new game\n");
			int i;
			for(i = 0; i < SIZE; i++)   //数组清0
			{
				arr[i] = 0;
			}
			init_2048();  //重新初始化		
			print_game();
		}
		//撤销
		if(e_x>699 && e_x<799 && e_y>299 && e_y<399){
			printf("revoke\n");
			redo_revoke(head_game->list.prev);
		}
		//反撤销
		if(e_x>699 && e_x<799 && e_y>199 && e_y<299){
			printf("redo\n");
			redo_revoke(head_game->list.next);
		}
		//保存
		if(e_x>699 && e_x<799 && e_y>0 && e_y<99){
			save_gamelist(head_game);
		}
		//退出
		if(e_x>699 && e_x<799 && e_y>399 && e_y<479){
			save_gamelist(head_game);	//保存数据
			clear_gamelist(&head_game);	//清空链表
			free(head_game);			//释放头结点
			head_game = NULL;
			printf("exit game\n");	
			break;
		}		
	}
	
	close_font();
	return; 
}

//恢复游戏数据
bool show_last_data()
{
	if(!show_last(&head_game))	//查找上次退出时的游戏数据(is_last为1),把头结点移到当前位置
	{
		printf("找不到数据\n");
		//游戏初始化
		init_2048();
		//显示一维数组的数据和得分,历史最高分，并判断游戏是否结束
		print_game();
		return false;
	}
		
	printf("成功找到数据\n");
	int i;
	for(i=0;i<16;i++){
		arr[i] = head_game->data.arr[i];
	}
	total = head_game->data.total;
	his_total = head_game->data.his_total;

	print_game();
	return true;
}


//把移动后的数据插入链表
void update_data()
{
	//{每次移动后删除当前位置到链表尾部之间的数据，让反撤销无效(无法后移)
	//不包括当前节点
	struct list_head *pos = NULL,*n=NULL,*pos_del;		
	
	GAME_NODE_P p = NULL,head_save = head_game;	//保存当前位置
	
	pos_del = head_save->list.next;				//指针后移
	p = list_entry(pos_del,GAME_NODE,list);		//获取下一个节点数据
	
	head_game = move_gamelist_head();			//移动到头节点
	
	for(; p != head_game; pos_del = pos)		//删除当前位置到链表尾部之间的节点
	{	
		pos = p->list.next;						//指针后移
		p = list_entry(pos,GAME_NODE,list);		//获取下一个节点数据
		list_del(pos_del);						//删除节点		
	}	
	head_game = head_save;						//回到原来的位置	
	//}
	
	//{把移动后的数据插入链表
	head_game->data.is_last = 0;
	//新建节点插入链表，并把头结点下移
	//参数：当前分数，历史最高分保存在头结点，是否当前位置，一维数组地址
	head_game = add_game_node(total,his_total,1,arr);
	//}
	
	
	//{判断链表长度是否大于4，是则删除链表头的下一个节点(只能撤销三步)
	head_save = head_game;
	head_game = move_gamelist_head();
	int len = 0;
	list_for_each(pos,&head_game->list){
		p = list_entry(pos,GAME_NODE,list);
		if(p != head_game)
			len++;
		if(len > 4){
			pos_del = head_game->list.next;
			p = list_entry(pos_del,GAME_NODE,list);
			list_del(pos_del);
			free(p);
			p = NULL;
		}
	}
	head_game = head_save;
	//}
	save_gamelist(head_game);
	return;
}

//撤销/重做
void redo_revoke(struct list_head *pos)
{	
	GAME_NODE_P p = NULL;				//用于获取上/下一个节点的数据
	GAME_NODE_P head_save = head_game;	//保存当前节点位置
	
	head_game->data.is_last = 0;
	
	//pos = head_game->list.prev;		   //指针前移
	//pos = head_game->list.next;		   //指针后移
	p = list_entry(pos,GAME_NODE,list);//获取上/下一个节点的数据
	
	head_game = move_gamelist_head();  //最多到达头结点或链表尾
	if(p == head_game){
		printf("到达末尾！\n");		
		p = head_save;				   //返回当前位置		
	}
	
	p->data.is_last = 1;				//头结点前移/后移
	head_game = p;

	int i;								//获取上/下一个节点的数据
	for(i=0;i<16;i++)
	{
		arr[i] = head_game->data.arr[i];
	}	
	total = head_game->data.total;
	his_total = head_game->data.his_total;

	print_game();
	return;
}

//显示一维数组的数据和得分，并判断游戏是否结束,判断历史最高分
void print_game(void)
{
	int i;
	
	//获取当前数组信息
	for(i=0;i< SIZE;i++)
	{
		if(! arr[i])
			show2048(-1,i,total,his_total);		//为零时显示空格子
		
		show2048(arr[i],i,total,his_total);		//显示相应数字
	}
	
	max_num();	//读取最大数字，并判断是不是2048
	
	if(is_dead()) //如果能进这个if，说明game over，然后点击任意位置重新玩
    {
        int i;
        printf("game over!\n");
		
		//显示GAME OVER，然后点击任意位置重新玩
		show_gameover();
		while(1)
		{
			int s_x,s_y,e_x,e_y;		
			ts_get_xy(&s_x,&s_y,&e_x,&e_y);
			if(e_x >0)
				break;
		}

        for(i = 0; i < SIZE; i++)   //数组清0
        {
            arr[i] = 0;
        }
        init_2048();  //重新初始化
		lcd_draw_bmp(0,0,"/album/2048/2048back.bmp");
        print_game();
    }
	
}

//初始化数组，产生两个不同的随机数，从0-15产生，对应数组下标，然后把该下标数组的值设置为2
void init_2048(void)
{
	//清空链表
	clear_gamelist(&head_game);
	
    int i, random1, random2;
    random1 = rand() % SIZE;
    for(i = 0; i < 1; i++)
    {
        random2 = rand() % SIZE;
        if(random1 == random2)
        {
            i--;
        }
    }
    arr[random1] = 2;
    arr[random2] = 2;
	max = 2;
	total = 0;
	
	//新建节点插入链表，并把头结点下移
	//参数：当前分数，历史最高分，是否当前位置，一维数组地址
	head_game = add_game_node(total,his_total,1,arr);	

	return;
}

//判断是否不能移动并且合并，就是game over了
int is_dead()
{
    int i, j;
    for(i = 0; i < SIZE; i++)
    {
        if(!arr[i])  //如果数组当中还有0，说明还能移动，返回0，说明游戏还没结束呢
        {
            return 0;
        }
    }
//到这里说明，的确在一个方向不能移动了，但是，有可能换个方向还可以移动，所以能到这里说明，16个格子全部有数字，都不为0，接下来判断4行，4列
//每相邻两个数字,是否有相同的如果有说明通过移动还可以动，这时候还没死呢
    for(i = 0; i < SIZE; i += 4)
    {
        for(j = i; j < i + 3; j++)
        {
            if(arr[j] == arr[j + 1])  //这里就是判断4行，一行一行看，每相邻两个格子如果数字有相同的，return 0，说明游戏还可以继续
            {
                return 0;
            }
        }
    }
    for(i = 0; i < 4; i++)
    {
        for(j = i; j < i + 12; j += 4)
        {
            if(arr[j] == arr[j + 4])  //这里判断4列，一列一列看，每相邻两个格子如果有数字相同的，return 0，说明游戏还可以继续
            {
                return 0;
            }
        }
    }
    return 1;    // 能到这里，说明16个格子全部都有数字，都不为0，而且各个方向无论怎么移动都不能合并，那么游戏结束game over，return 1
}

//  这个函数返回当前最大的数字,判断是否胜利 
int max_num(void)
{	
	max = arr[0];
    int i;
    static int count = 0;
    for(i = 0; i < SIZE; i++)
    {
        if(arr[i] > max)
        {
            max = arr[i];  //找最大数
        }
    }
    if(!count && 2048 == max)  //判断如果最大数==2048，过关，点击任意位置继续玩
    {
        count++;
        printf("恭喜过关,点击任意位置继续\n");
		show_win();
		while(1)
		{
			int s_x,s_y,e_x,e_y;		
			ts_get_xy(&s_x,&s_y,&e_x,&e_y);
			if(e_x >0)
				break;
		}
		for(i = 0; i < SIZE; i++)   //数组清0
        {
            arr[i] = 0;
        }
        init_2048();  //重新初始化
		lcd_draw_bmp(0,0,"/album/2048/2048back.bmp");
        print_game();		
    }
    return max;
}

//在数组的随机一个空位生成一个2，1/5的几率产生4
void rand_num(void) 
{
    while(is_move || is_merge)  //如果可以移动，或者可以合并，那么才能产生数字，
    {
        int random = rand() % SIZE;
        if(!arr[random])         //这个就是保证产生的随机数是空白中的，已经格子中已经有的就不行，重新产生
        {
			int random24 = rand() %10;
			if(random24 > 1){		//1/5的几率产生4
				arr[random] = 2;
			}
            else
				arr[random] = 4;
            break;
        }
    }
    is_move = 0;
    is_merge = 0;
}

//合并函数，只负责一次合并，把接收当前数字下标，把它上或者下或者左或者右的格子合并一个
void merge(int current_i, int direction)
{
//如果当前这个格子和它四个方向相邻的格子都不为0时并且，这两个数字相等时才进行合并操作
    if(arr[current_i] && arr[current_i + direction] && arr[current_i] == arr[current_i + direction])
    {
        arr[current_i] = arr[current_i + direction] * 2;
        total += arr[current_i];
		
		if(total > his_total)
			his_total = total;
				
		struct list_head *pos = NULL;
		GAME_NODE_P head_save = head_game;		//保存当前位置
		head_game = move_gamelist_head();		//移动到头结点
		
		GAME_NODE_P p = NULL;
		list_for_each(pos,&head_game->list){	//遍历全部节点，更新历史最高分
			p = list_entry(pos,GAME_NODE,list);
			p->data.his_total = his_total;
		}
		
		head_game = head_save;		//回到原来的位置
        arr[current_i + direction] = 0;
        is_merge = 1; 
    }
}


//函数说明
//{
//移动的主要函数，最重要的地方，这个函数接收三个参数，loop_count，需要循环的次数，current_i，当前移动的元素数组下标，
//direction这个是因为有上下左右四个方向，比如当前元素是  arr[5],那么它左边的格子就是arr[5-1],右边就是arr[5+1],
//上边就是arr[5-4],下边就是arr[5+4],这里的 1，-1,4，-4就是direction，就是把四个方向的函数提取出相同的部分，公用这一个移动方法，用direction区分方向
//移动是被move_up ...等等这些函数调用的，所以请先去看move_up ...等等函数的作用
//先说一下，move_up_pre这个函数结合了移动、合并，这个函数调用了move_up这个函数，而move_up 又会调用move_go这个函数，所以先去看move_up_pre函数是干啥的
//OK，从move_up 这个函数过来了，那么我举个例子吧：
//比如现在当前的i是5 ，即第二行第2个数字2，需要向上移动，那么它的循环次数是1次，direction=-4，说明它上面的那个数字下标比当前这个小4
//if(arr[current_i] && !arr[current_i + direction])  如果当前这个数字不为0，并且它上面的那个数字为0那么就可以向上移动
//} 

//把下标current_i位置的格子往 direction方向 移动loop_count次
void move_go(int loop_count, int current_i, int direction)
{
    int i;
    for(i = 0; i < loop_count; i++)
    {
        if(arr[current_i] && !arr[current_i + direction])
        {
            arr[current_i + direction] = arr[current_i];  //把它上面那个数字改成当前这个数字，
            arr[current_i] = 0;  //把当前这个数字改成0
            current_i += direction;  //再把当前的current_i ,-4,继续看它上面是什么情况，能移动就移动不能移动就算了
            is_move = 1;   //能进来说明能移动，所以把标志 是否能移动 设置为1
        }
    }
}
//OK这个函数完了，就完成了一次单纯的移动操作，那么向左，向右，向下一个道理，我就不说了，下来去看move_up_pre函数去

//计算每个格子向上的移动次数，并向上移动全部格子
void move_up(void)
{
    // loop_count循环次数，为啥会有这个变量，因为向上移动有的数字需要移动一次，有的需要移动2,3次，而最上边的数字则不需要移动所以，
    //loop_count控制循环次数，direction，控制方向，向上移动所以是以从下往上的角度看的，那么direction=-4，意思就是上一个元素的下标比当前元素小4
    //所以是-4.
    int i, loop_count, direction;  
    for(i = 0; i < SIZE; i++)
    {
        if(arr[i])  //移动时，如果这个格子的数字不为0才移动，为0的话不用管了，能进到这个if说明当前要移动的数字不为0，也就是不是空白，空白不需要移动
        {
            loop_count = i / 4;  
//计算循环次数，0 1 2 3，是最上层的数字不用移动，所以i /4=0,不用移动，第二行4,5,6,7，最多需要移动1次，i/4=1,依次类推
            direction = -4;
//把当前格子中的数组下标，需要循环的次数，还有方向传给move_go 这个函数，接下来去看move_go 这个函数
            move_go(loop_count, i, direction);
        }
    }
}
//好OK，这个函数就是负责向上移动，不用管数字是否相同还是不同，全部一个顶一个一个顶一个移动到一个方向

void move_down(void)
{
    int i, loop_count, direction;
    for(i = SIZE - 1; i >= 0; i--)
    {
        if(arr[i])
        {
            loop_count = (4 - 1) - i / 4;
            direction = 4;
            move_go(loop_count, i, direction); 
        }
    }
} 
 
void move_right(void)
{
    int i, loop_count, direction;
    for(i = SIZE - 1; i >= 0; i--)
    {
        if(arr[i])
        {
            loop_count = (4 - 1) - (i + 4) % 4;
            direction = 1;
            move_go(loop_count, i, direction);
        }
    }
}
 
 
void move_left(void)
{
    int i, loop_count, direction;
    for(i = 0; i < SIZE; i++)
    {
        if(arr[i])
        {
            loop_count = (i + 4) % 4;
            direction = -1;
            move_go(loop_count, i, direction);
        }
    }
}

//这个就是我之前说的分三步，第一步移动清楚空白，第二步合并，第三步移动清楚空白完成一次移动合并操作，下来我仔细讲一下
void move_up_pre(void)
{
    move_up();  //先调用移动方法去除空白，那么先去move_up 看这个函数是干啥的，OK看完move_up 函数，再往下看
// 两个move_up 中间夹着的就是合并的动作，同样merge合并的这个函数也是接收一个direction参数，四个方向的合并公用一个方法
// 继续上面的向上移动上去的那个接着画个图
//那么合并操作完成，应该是这个样子，粉色的2其实已经合并了，是不存在的我先放在那里，是想说明我的合并方法会产生空白，所以需要再做一遍移动操作
//向上合并，那么我从上往下看，现在先看第一行的第一个数字，当然如果没有数字那就不合并了，现在假设都有数字
//和它下面的数字比较，就是竖着往下走，如果相同，把第一个数字乘2，第二个数字设置为0 ，然后看第二个数字
//和第三个数字，那么这会其实没必要比较第二个和第三个，直接去比较第三个和第第四个就行了，但是
//我不想分情况了，就直接往下比较吧，白做一次比较，然后就这样依次往后比较
    int i, j, direction = 4; //合并是从上往下看，所以direction=4，即它下面的那个格子数组下标比当前这个大4
    for(i = 0; i < 4; i++)  
// 这里的i从0 到3 ，即0,1,2,3，控制列数，即0开头的那一列，1开头的那一列，以此类推
    {
        for(j = i; j < i + 12; j += 4)
//  当i=0时,j 是0,4,8，当i=1时，j是1,5,9以此类推,传给merge进行合并，关于下、左、右合并道理类似，我就不说了
        {
            merge(j, direction);
        }
    }
    move_up();
}

void move_down_pre(void)
{
    move_down();
    int i, j, direction = -4;
    for(i = 4 - 1; i >= 0; i--)
    {
        for(j = i + 12; j >= 4; j -= 4)
        {
            merge(j, direction);
        }
    }
    move_down();
}

void move_right_pre(void)
{
    move_right();
    int i, j, direction = -1;
    for(i = 4 - 1; i >= 0; i--)
    {
        for(j = 4 * i + 3; j > 4 * i; j--)
        {
            merge(j, direction);
        }
    }
    move_right();
}

void move_left_pre(void)
{
    move_left();
    int i, j, direction = 1;
    for(i = 0; i <= 3; i++)
    {
        for(j = 4 * i; j < 4 * i + 3; j++)
        {
            merge(j, direction);
        }
    }
    move_left();
}



