#include "albumlist.h"

//查看照片是否存在
bool is_exist(PIC_NODE_P head,char *name)
{
	struct list_head *pos = NULL;
	PIC_NODE_P p = NULL;
	
	list_for_each(pos,&head->list){
		p = list_entry(pos,PIC_NODE,list);
		if(strcmp(name,p->pic.name) == 0)
		return true;
	}
	return false;
}

//查找上次最后打开的照片
PIC_NODE_P is_last(PIC_NODE_P *head)
{
	struct list_head *pos = NULL;
	PIC_NODE_P p = NULL;
	
	list_for_each(pos,head_pos){
		p = list_entry(pos,PIC_NODE,list);
		if(p->pic.last){
			*head = p;
			return p;
		}
	}
	return NULL;
}

//判空
bool is_empty(PIC_NODE_P head)
{
	PIC_NODE_P head_save = head;
	head = move_head();
	if(!head){
		perror("head is NULL!");
		return false;
	}
	
	if(list_empty(&head->list))
	{
		printf("list is NULL!\n");
		return false;
	}
	head = head_save;
	return true;
}

//头结点初始化
PIC_NODE_P init_list(void)
{
	PIC_NODE_P head = calloc(1, sizeof(struct pic_node));
	if(head != NULL)
	{
		// head->list.prev = &head->list;
		// head->list.next = &head->list;
		INIT_LIST_HEAD(&head->list);
	}
	
	head_pos = &head->list;
	return head;
}

//返回链表的头结点的位置
PIC_NODE_P move_head(void)
{	
	struct list_head *pos = head_pos;
	PIC_NODE_P p = list_entry(pos,PIC_NODE,list);
	return p;
}

//新建节点
PIC_NODE_P new_node(PIC_P pic)
{
	PIC_NODE_P new = calloc(1, sizeof(struct pic_node));
	if(new != NULL)
	{
		new->pic = *pic;
		//初始化指针域
		INIT_LIST_HEAD(&new->list);
	}
	return new;
}

//遍历
void show(PIC_NODE_P head)
{
	//判空
	if(!is_empty(head))  return ;
	
	struct list_head *pos;
	PIC_NODE_P p;
	
	printf("存在的相片有：\n");
	list_for_each(pos, &head->list)
	{
		p = list_entry(pos, struct pic_node, list);
		printf("%s\n",p->pic.name);
	}
	return;
}

// 清空链表
void quit_album(PIC_NODE_P *head)
{
	//判空
	if(!is_empty(*head))	return ;
	
	PIC_NODE_P p;
	struct list_head *pos,*n;
	
	list_for_each_safe(pos,n,&((*head)->list))
	{
		p = list_entry(pos,PIC_NODE,list);
		list_del(pos);
		free(p);
		p = NULL;
	}
	
	return;
}

//保存数据
void save(PIC_NODE_P head)
{
	if(!is_empty(head))	return ;
	
	PIC_NODE_P head_save = head;
	head = move_head();
	
	FILE *fp = fopen("albumlist.dat","w");
	if(!fp)
	{
		perror("fopen error\n");
		exit(-1);
	}
	
	printf("fopen  albumlist.dat\n");
	
	struct list_head *pos;
	PIC_NODE_P p;

	list_for_each(pos, &head->list)
	{
		p = list_entry(pos, struct pic_node, list);
		fwrite(&p->pic,sizeof(PIC),1,fp);
	}
	printf("保存相册数据成功！\n");
	
	head = head_save;
	printf("fclose\n");
	fclose(fp);
	return ;
}

//读取数据
bool read_data(PIC_NODE_P *head)
{
	*head = init_list();//新建链表
	PIC pic;
	
	FILE *fp = fopen("albumlist.dat","r");
	if(!fp)
	{
		perror("fopen error!\n");
		return false;
	}
	printf("fopen albumlist.dat\n");

	while(1)
	{
		memset(&pic,0,sizeof(PIC));
		fread(&pic,sizeof(PIC),1,fp); 	  // 获取数据
		
		if(feof(fp) || ferror(fp))
		{
			break;
		}
		
		FILE *picfp = fopen(pic.path,"r");
		if(!picfp)
		{
			printf("fopen %s error!\n",pic.path);
			continue;
		}
		//printf("fopen %s\n",pic.path);

		PIC_NODE_P new = new_node(&pic); // 新建节点
		list_add_tail(&new->list,&((*head)->list));// 插入链表

		fclose(picfp);
	}
	show(*head);
	printf("fclose\n");
	fclose(fp);
	return true;
}






