#include "gamelist.h"

//头结点初始化
GAME_NODE_P init_gamelist(void)
{
	GAME_NODE_P head = calloc(1, sizeof(GAME_NODE));
	if(head != NULL)
	{
		// head->list.prev = &head->list;
		// head->list.next = &head->list;
		INIT_LIST_HEAD(&head->list);
	}
	head_pos_g = &head->list;
	return head;
}

//判空
bool is_gamelist_empty(GAME_NODE_P head)
{
	head = move_gamelist_head();
	if(!head){
		perror("head is NULL!");
		return false;
	}
	
	if(list_empty(&head->list))
	{
		printf("list is NULL!\n");
		return false;
	}

	return true;
}

//返回链表的头结点的位置
GAME_NODE_P move_gamelist_head(void)
{	
	struct list_head *pos = head_pos_g;
	
	GAME_NODE_P p = list_entry(pos,GAME_NODE,list);
	return p;
}

// 清空链表
void clear_gamelist(GAME_NODE_P *head)
{
	//判空
	if(!is_gamelist_empty(*head))	return ;
	
	GAME_NODE_P p;
	struct list_head *pos=NULL,*n=NULL;
	
	*head = move_gamelist_head();
	list_for_each_safe(pos,n,&(*head)->list)
	{
		p = list_entry(pos,GAME_NODE,list);
		list_del(pos);
		free(p);
		p = NULL;
	}
	printf("清空链表成功\n");
	return;
}

//新建节点
GAME_NODE_P new_game_node(ST_GAME_P data)
{
	GAME_NODE_P new = calloc(1, sizeof(GAME_NODE));
	if(new){
		new->data = *data;		
		INIT_LIST_HEAD(&new->list);		//初始化指针域
	}
	return new;
}

//把数据插入链表尾部，返回到尾部节点的位置
GAME_NODE_P add_game_node(int total,int his_total,int is_last,int *arr)
{
	ST_GAME data;
	
	data.total = total;
	data.his_total = his_total;
	data.is_last = is_last;						//拷贝数据
	
	int i;
	for(i=0;i<16;i++)
	{
		data.arr[i] = *arr++;
	}
	
	GAME_NODE_P new = new_game_node(&data); 	//新建节点
	
	head_game = move_gamelist_head();			//移动到头结点
	list_add_tail(&new->list,&head_game->list);	//插入到链表尾部
	
	struct list_head *pos = head_game->list.prev;	//移到链表尾部
	GAME_NODE_P p = list_entry(pos,GAME_NODE,list);

	return p;										//返回最后一个节点
}

//保存数据
void save_gamelist(GAME_NODE_P head)
{
	if(!is_gamelist_empty(head))	return ;
	
	head = move_gamelist_head();		//移动到头结点
	
	FILE *fp = fopen("gamelist.dat","w");
	if(!fp)
	{
		perror("fopen gamelist.dat error");
		exit(-1);
	}
	
	printf("fopen  gamelist.dat\n");
	
	struct list_head *pos = NULL;
	GAME_NODE_P p = NULL;

	list_for_each(pos, &head->list)
	{
		p = list_entry(pos, GAME_NODE, list);
		fwrite(&p->data,sizeof(ST_GAME),1,fp);	//遍历保存
	}
	//printf("保存游戏数据成功！\n");
	
	printf("fclose\n");
	fclose(fp);
	return ;
}

//读取数据
bool read_gamelist(GAME_NODE_P *head)
{
	*head = init_gamelist();//初始化链表
	ST_GAME data;
	
	FILE *fp = fopen("gamelist.dat","r");
	if(!fp)
	{
		perror("fopen gamelist.dat error!\n");
		return false;
	}
	printf("fopen gamelist.dat error\n");

	while(1)
	{
		memset(&data,0,sizeof(ST_GAME));
		fread(&data,sizeof(ST_GAME),1,fp); 	  // 获取数据
		
		if(feof(fp) || ferror(fp))
		{
			break;
		}

		add_game_node(data.total,data.his_total,data.is_last,data.arr);	// 插入链表
		
	}

	printf("fclose\n");
	fclose(fp);
	return true;
}

//查找is_last为1的节点，把头结点移动到这个节点
bool show_last(GAME_NODE_P *head)
{
	struct list_head *pos = NULL;
	GAME_NODE_P p = move_gamelist_head();	//移动到头结点
		 
	list_for_each(pos,&p->list){
		p = list_entry(pos,GAME_NODE,list);
		if(p->data.is_last == 1){			//查找is_last为1的节点，把头结点移动到这个节点
			*head = p;			
			
			return true;
		}
	}
	
	return false;	//找不到返回空
}



